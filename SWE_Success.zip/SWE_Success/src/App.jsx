import './App.css';
import Opportunities from './components/Opportunities'
const App = () => {

  return (
    <div className="App">
        <h1>First-Year's Guide to SWE</h1>
        <h2>New to software engineering? We got you covered!</h2>
        <Opportunities />
    </div>
  )
}

export default App
